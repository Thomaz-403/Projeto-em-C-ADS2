#include "jogos.h"

/* Inicializa todas as posições do vetor com NULL */
void inicializar(Jogo *vetor[]) {
    int i;
    for (i = 0; i < MAX; i++) {
        vetor[i] = NULL;
    }
}

/* Libera a memória de todos os registros alocados */
void liberarMemoria(Jogo *vetor[]) {
    int i;
    for (i = 0; i < MAX; i++) {
        if (vetor[i] != NULL) {
            free(vetor[i]);
            vetor[i] = NULL;
        }
    }
}

/* Conta quantos jogos estão cadastrados */
int quantidadeJogos(Jogo *vetor[]) {
    int i, qtd = 0;
    for (i = 0; i < MAX; i++) {
        if (vetor[i] != NULL) {
            qtd++;
        }
    }
    return qtd;
}

/* Cadastra um novo jogo alocando memória sob demanda */
int cadastrar(Jogo *vetor[]) {
    int i, codigo;
    Jogo *novo;

    /* Procura a primeira posição livre */
    for (i = 0; i < MAX; i++) {
        if (vetor[i] == NULL) {
            break;
        }
    }

    if (i == MAX) {
        printf("\n>>> Capacidade maxima atingida! Nao e possivel cadastrar mais jogos.\n");
        return 0;
    }

    /* Aloca memória apenas para o novo registro */
    novo = (Jogo *) malloc(sizeof(Jogo));
    if (novo == NULL) {
        printf("\n>>> Erro: falha na alocacao de memoria!\n");
        return 0;
    }

    printf("\n=== CADASTRO DE NOVO JOGO ===\n");

    /* Lê o código e verifica se já existe */
    printf("Codigo do jogo: ");
    scanf("%d", &codigo);
    getchar(); /* consome o \n residual */

    /* Verifica duplicidade de código */
    {
        int j;
        for (j = 0; j < MAX; j++) {
            if (vetor[j] != NULL && vetor[j]->codigo == codigo) {
                printf(">>> Codigo ja existente! Cadastro cancelado.\n");
                free(novo);
                return 0;
            }
        }
    }

    novo->codigo = codigo;

    printf("Titulo: ");
    fgets(novo->titulo, TAM_TITULO, stdin);
    novo->titulo[strcspn(novo->titulo, "\n")] = '\0'; /* remove \n */

    printf("Desenvolvedora: ");
    fgets(novo->desenvolvedora, TAM_DEV, stdin);
    novo->desenvolvedora[strcspn(novo->desenvolvedora, "\n")] = '\0';

    printf("Preco (R$): ");
    scanf("%f", &novo->preco);

    printf("Horas jogadas: ");
    scanf("%f", &novo->horasJogadas);
    getchar();

    vetor[i] = novo;
    printf("\n>>> Jogo cadastrado com sucesso na posicao %d!\n", i);
    return 1;
}

/* Lista todos os jogos não nulos */
void listarTodos(Jogo *vetor[]) {
    int i, qtd = 0;

    printf("\n=== LISTA DE TODOS OS JOGOS ===\n");
    printf("%-8s %-30s %-20s %10s %12s\n",
           "Codigo", "Titulo", "Desenvolvedora", "Preco", "Horas");
    printf("--------------------------------------------------------------------------------\n");

    for (i = 0; i < MAX; i++) {
        if (vetor[i] != NULL) {
            printf("%-8d %-30s %-20s %10.2f %12.1f\n",
                   vetor[i]->codigo,
                   vetor[i]->titulo,
                   vetor[i]->desenvolvedora,
                   vetor[i]->preco,
                   vetor[i]->horasJogadas);
            qtd++;
        }
    }

    if (qtd == 0) {
        printf("Nenhum jogo cadastrado.\n");
    } else {
        printf("--------------------------------------------------------------------------------\n");
        printf("Total de jogos: %d\n", qtd);
    }
}

/* Busca um jogo pelo código e exibe seus detalhes */
void buscarPorCodigo(Jogo *vetor[]) {
    int codigo, i, encontrado = 0;

    printf("\n=== BUSCA POR CODIGO ===\n");
    printf("Informe o codigo do jogo: ");
    scanf("%d", &codigo);
    getchar();

    for (i = 0; i < MAX; i++) {
        if (vetor[i] != NULL && vetor[i]->codigo == codigo) {
            printf("\n--- Dados do Jogo ---\n");
            printf("Codigo........: %d\n", vetor[i]->codigo);
            printf("Titulo........: %s\n", vetor[i]->titulo);
            printf("Desenvolvedora: %s\n", vetor[i]->desenvolvedora);
            printf("Preco.........: R$ %.2f\n", vetor[i]->preco);
            printf("Horas Jogadas.: %.1f h\n", vetor[i]->horasJogadas);
            encontrado = 1;
            break;
        }
    }

    if (!encontrado) {
        printf(">>> Jogo com codigo %d nao encontrado.\n", codigo);
    }
}

/* Relatório: média de preço e jogo com maior tempo jogado */
void relatorio(Jogo *vetor[]) {
    int i, qtd = 0;
    float somaPreco = 0.0f;
    float maiorHoras = -1.0f;
    Jogo *jogoMaisJogado = NULL;

    for (i = 0; i < MAX; i++) {
        if (vetor[i] != NULL) {
            somaPreco += vetor[i]->preco;
            qtd++;
            if (vetor[i]->horasJogadas > maiorHoras) {
                maiorHoras = vetor[i]->horasJogadas;
                jogoMaisJogado = vetor[i];
            }
        }
    }

    printf("\n=== RELATORIO / ESTATISTICAS ===\n");

    if (qtd == 0) {
        printf("Nenhum jogo cadastrado para gerar relatorio.\n");
        return;
    }

    printf("Quantidade de jogos cadastrados: %d\n", qtd);
    printf("Media de preco dos jogos.......: R$ %.2f\n", somaPreco / qtd);

    if (jogoMaisJogado != NULL) {
        printf("\n--- Jogo com MAIOR tempo jogado ---\n");
        printf("Codigo........: %d\n", jogoMaisJogado->codigo);
        printf("Titulo........: %s\n", jogoMaisJogado->titulo);
        printf("Desenvolvedora: %s\n", jogoMaisJogado->desenvolvedora);
        printf("Preco.........: R$ %.2f\n", jogoMaisJogado->preco);
        printf("Horas Jogadas.: %.1f h\n", jogoMaisJogado->horasJogadas);
    }
}

/* Carrega os dados do arquivo texto (se existir) */
void carregarArquivo(Jogo *vetor[]) {
    FILE *fp;
    char linha[256];
    int i = 0;
    int codigo;
    char titulo[TAM_TITULO];
    char desenvolvedora[TAM_DEV];
    float preco, horas;

    fp = fopen(ARQUIVO_DADOS, "r");
    if (fp == NULL) {
        /* Arquivo não existe: inicia vazio sem erro */
        printf("Arquivo de dados nao encontrado. Sistema iniciado vazio.\n");
        return;
    }

    while (fgets(linha, sizeof(linha), fp) != NULL && i < MAX) {
        /* Formato esperado: codigo;titulo;desenvolvedora;preco;horas */
        if (sscanf(linha, "%d;%79[^;];%59[^;];%f;%f",
                   &codigo, titulo, desenvolvedora, &preco, &horas) == 5) {

            vetor[i] = (Jogo *) malloc(sizeof(Jogo));
            if (vetor[i] == NULL) {
                printf("Erro de alocacao ao carregar arquivo.\n");
                break;
            }
            vetor[i]->codigo = codigo;
            strncpy(vetor[i]->titulo, titulo, TAM_TITULO - 1);
            vetor[i]->titulo[TAM_TITULO - 1] = '\0';
            strncpy(vetor[i]->desenvolvedora, desenvolvedora, TAM_DEV - 1);
            vetor[i]->desenvolvedora[TAM_DEV - 1] = '\0';
            vetor[i]->preco = preco;
            vetor[i]->horasJogadas = horas;
            i++;
        }
    }

    fclose(fp);
    printf("Dados carregados com sucesso: %d jogo(s).\n", i);
}

/* Salva todos os registros no arquivo texto */
void salvarArquivo(Jogo *vetor[]) {
    FILE *fp;
    int i, qtd = 0;

    fp = fopen(ARQUIVO_DADOS, "w");
    if (fp == NULL) {
        printf(">>> Erro ao abrir arquivo para gravacao!\n");
        return;
    }

    for (i = 0; i < MAX; i++) {
        if (vetor[i] != NULL) {
            fprintf(fp, "%d;%s;%s;%.2f;%.1f\n",
                    vetor[i]->codigo,
                    vetor[i]->titulo,
                    vetor[i]->desenvolvedora,
                    vetor[i]->preco,
                    vetor[i]->horasJogadas);
            qtd++;
        }
    }

    fclose(fp);
    printf(">>> Dados salvos com sucesso (%d registro(s)).\n", qtd);
}
