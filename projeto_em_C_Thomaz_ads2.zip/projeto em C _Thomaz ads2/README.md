# Catálogo de Jogos Digitais

Sistema modular com persistência em arquivo texto desenvolvido em linguagem C, utilizando TAD (Tipo Abstrato de Dados), ponteiros, structs e alocação dinâmica de memória.

## 1. Identificação

| Nome Completo              | RA          |
|----------------------------|-------------|
| Thomaz Lanzi Barbosa       | -           |

## 2. Motivo da Escolha do Tema

Optei pelo Tema 1 – Catálogo de Jogos Digitais por ser um domínio familiar, que permite modelar dados variados (código inteiro, strings de título e desenvolvedora, preço e horas jogadas em ponto flutuante). O relatório solicitado (média de preço e jogo com maior tempo jogado) se encaixa no uso de percorrimento do vetor de ponteiros e cálculos sobre os registros cadastrados.

## 3. Como o Problema Foi Atacado e Modelado

O projeto foi organizado em três arquivos principais (jogos.h, jogos.c e main.c), utilizando vetor de ponteiros com alocação dinâmica sob demanda e arquivo texto para persistência dos dados.

## 4. Instruções de Compilação e Execução

### Compilação
```bash
gcc -Wall -Wextra -std=c99 -o catalogo_jogos main.c jogos.c
```

### Execução
```bash
./catalogo_jogos
```

No Windows:
```cmd
gcc -Wall -Wextra -std=c99 -o catalogo_jogos.exe main.c jogos.c
catalogo_jogos.exe
```
