#ifndef JOGOS_H
#define JOGOS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100
#define TAM_TITULO 80
#define TAM_DEV 60
#define ARQUIVO_DADOS "dados.txt"

/* Estrutura que representa um jogo digital */
typedef struct {
    int codigo;                 /* Identificador único */
    char titulo[TAM_TITULO];    /* Título do jogo */
    char desenvolvedora[TAM_DEV]; /* Nome da desenvolvedora */
    float preco;                /* Preço em reais */
    float horasJogadas;         /* Horas jogadas pelo usuário */
} Jogo;

/* Protótipos das funções do TAD */

/* Inicializa o vetor de ponteiros com NULL */
void inicializar(Jogo *vetor[]);

/* Libera toda a memória alocada dinamicamente */
void liberarMemoria(Jogo *vetor[]);

/* Retorna a quantidade de jogos cadastrados (posições não nulas) */
int quantidadeJogos(Jogo *vetor[]);

/* Cadastra um novo jogo (aloca memória sob demanda) */
int cadastrar(Jogo *vetor[]);

/* Lista todos os jogos cadastrados */
void listarTodos(Jogo *vetor[]);

/* Busca e exibe um jogo pelo código */
void buscarPorCodigo(Jogo *vetor[]);

/* Relatório: média de preço e jogo com maior tempo jogado */
void relatorio(Jogo *vetor[]);

/* Carrega os dados do arquivo texto para o vetor */
void carregarArquivo(Jogo *vetor[]);

/* Salva os dados do vetor no arquivo texto */
void salvarArquivo(Jogo *vetor[]);

#endif
