#include <stdio.h>
#include <stdlib.h>
#include "jogos.h"

/* Exibe o menu principal */
void exibirMenu(void) {
    printf("\n========================================\n");
    printf("   CATALOGO DE JOGOS DIGITAIS\n");
    printf("========================================\n");
    printf("  1. Cadastrar jogo\n");
    printf("  2. Listar todos os jogos\n");
    printf("  3. Buscar jogo por codigo\n");
    printf("  4. Relatorio / Estatisticas\n");
    printf("  5. Salvar e Sair\n");
    printf("========================================\n");
    printf("Escolha uma opcao: ");
}

int main(void) {
    Jogo *catalogo[MAX];
    int opcao;

    /* Inicializa o vetor de ponteiros com NULL */
    inicializar(catalogo);

    /* Carrega dados existentes do arquivo (se houver) */
    printf("Iniciando sistema...\n");
    carregarArquivo(catalogo);

    /* Laço principal do menu (do-while + switch-case) */
    do {
        exibirMenu();
        scanf("%d", &opcao);
        getchar(); /* consome o \n */

        switch (opcao) {
            case 1:
                cadastrar(catalogo);
                break;
            case 2:
                listarTodos(catalogo);
                break;
            case 3:
                buscarPorCodigo(catalogo);
                break;
            case 4:
                relatorio(catalogo);
                break;
            case 5:
                printf("\nSalvando dados e encerrando...\n");
                salvarArquivo(catalogo);
                liberarMemoria(catalogo);
                printf("Memoria liberada. Ate logo!\n");
                break;
            default:
                printf("\n>>> Opcao invalida! Tente novamente.\n");
        }
    } while (opcao != 5);

    return 0;
}
